extends ChunkLattice

@onready var Main = get_tree().root.get_child(0)

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if multiplayer.is_server():
		setup("world", Main.c_shape, Main.c_cube_size, Main.l_type, Main.l_seed)
	else:
		setup("client_empty", Main.c_shape, Main.c_cube_size, Main.l_type, Main.l_seed)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

# loading chunks
@rpc("authority", "call_remote", "reliable")
func rpc_client_update_mesh_chunk(chunk_idx: Vector3i, changes_idxs: PackedInt32Array, changes_fullness_values: PackedFloat32Array, changes_material_values: PackedByteArray):
	client_update_mesh_chunk(chunk_idx, changes_idxs, changes_fullness_values, changes_material_values)

@rpc("authority", "call_remote", "reliable")
func rpc_client_update_collision_chunk(chunk_idx: Vector3i):
	client_update_collision_chunk(chunk_idx)

@rpc("authority", "call_remote", "reliable")
func rpc_client_delete_chunk(chunk_idx: Vector3i):
	client_delete_chunk(chunk_idx)

# updating loaded chunks
